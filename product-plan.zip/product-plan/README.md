# bitCaster — Design Handoff

This folder contains everything needed to implement bitCaster, a Bitcoin-native prediction market platform built on Cashu, Nostr, and DLC oracles.

## What's Included

**Ready-to-Use Prompts:**
- `prompts/one-shot-prompt.md` — Prompt template for full implementation
- `prompts/section-prompt.md` — Prompt template for section-by-section implementation

**Instructions:**
- `product-overview.md` — Product summary (provide with every implementation)
- `instructions/one-shot-instructions.md` — All milestones combined for full implementation
- `instructions/incremental/` — 9 milestone instructions (foundation + 8 sections)

**Design Assets:**
- `design-system/` — Colors, fonts, design tokens
- `event-model/` — Domain events and entity relationships
- `shell/` — Application shell components (navigation, layout)
- `sections/` — 8 section component packages with test instructions

## How to Use This

### Option A: Incremental (Recommended)

Build your app milestone by milestone for better control:

1. Copy the `product-plan/` folder to your codebase
2. Start with Foundation (`instructions/incremental/01-foundation.md`) — includes design tokens, data model, routing, and application shell
3. For each section:
   - Open `prompts/section-prompt.md`
   - Fill in the section variables at the top (SECTION_NAME, SECTION_ID, NN)
   - Copy/paste into your coding agent
   - Answer questions and implement
4. Review and test after each milestone

**Milestone Order:**
1. `01-foundation.md` — Design tokens, routing, shell
2. `02-market-discovery-and-trading.md` — Core marketplace
3. `03-market-creation-and-management.md` — Creator dashboard
4. `04-portfolio.md` — Trading dashboard with positions and activity
5. `05-market-detail.md` — Market detail with trading, charts, and activity
6. `06-settings.md` — User preferences and configuration
7. `07-wallet-setup.md` — First-time onboarding wizard
8. `08-market-creation.md` — Seven-step market creation wizard
9. `09-deposit-withdraw.md` — Deposit/withdraw modal flows

### Option B: One-Shot

Build the entire app in one session:

1. Copy the `product-plan/` folder to your codebase
2. Open `prompts/one-shot-prompt.md`
3. Add any additional notes to the prompt
4. Copy/paste the prompt into your coding agent
5. Answer the agent's clarifying questions
6. Let the agent plan and implement everything

## Test-Driven Development

Each section includes a `tests.md` file with test-writing instructions. For best results:

1. Read `sections/[section-id]/tests.md` before implementing
2. Write failing tests based on the instructions
3. Implement the feature to make tests pass
4. Refactor while keeping tests green

The test instructions are **framework-agnostic** — they describe WHAT to test, not HOW. Adapt to your testing setup (Jest, Vitest, Playwright, Cypress, RSpec, Minitest, PHPUnit, etc.).

## Sections Overview

| Section | Description | Key Components |
|---------|-------------|----------------|
| **Market Discovery & Trading** | Core marketplace with tag navigation, filters, inline trading | MarketDiscovery, TagBar, FilterControls, MarketCard |
| **Market Creation & Management** | Creator dashboard with stats, analytics, market list | MarketCreationDashboard, StatCard, MarketRow, VolumeChart |
| **Portfolio** | Personal dashboard with positions, funds, P/L chart, activity | Portfolio, PLChart, PositionRow, FundRow, ActivityFeed |
| **Market Detail** | Full market view with trading panel, price charts, activity | MarketDetail, MarketHeader, TradingPanel, PriceChart |
| **Settings** | User preferences in 4 collapsible categories | Settings (General, Cashu, Nostr, Oracle) |
| **Wallet Setup** | First-time onboarding wizard | WalletSetupWizard, WelcomeLanding, CreateWallet, RecoverWallet |
| **Market Creation** | 7-step market creation wizard | MarketCreationWizard, OracleCheck, BasicInfo, Outcomes, etc. |
| **Deposit / Withdraw** | Modal flows for depositing/withdrawing sats | DepositWithdraw, MethodChooser, MintSelector, Numpad, etc. |

## Technology Notes

- Components are built with **React 19** and **TypeScript** strict mode
- Styling uses **Tailwind CSS** with blue/amber/slate color scheme
- Icons from **lucide-react**
- Supports **light and dark mode**
- Components are **props-based** and framework-agnostic for easy integration
- **Cashu** ecash protocol for token management
- **Nostr** (NDK) for decentralized identity and social features
- **DLC oracles** for trustless market resolution

## Tips

- **Use the pre-written prompts** — They include important clarifying questions about auth and data modeling.
- **Add your own notes** — Customize prompts with project-specific context when needed.
- **Build on your designs** — Use completed sections as the starting point for future feature development.
- **Review thoroughly** — Check plans and implementations carefully to catch details and inconsistencies.
- **Fill in the gaps** — Backend business logic may need manual additions. Incremental implementation helps you identify these along the way.

---

*Generated by Design OS*
