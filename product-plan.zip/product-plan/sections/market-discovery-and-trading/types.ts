// =============================================================================
// Tag Types
// =============================================================================

export interface MetaTag {
  id: string
  label: string
  description: string
}

export interface CategoryTag {
  id: string
  label: string
  marketCount: number
}

// Combined tag type for single-select behavior
export type Tag = MetaTag | CategoryTag

// =============================================================================
// Market Data Types
// =============================================================================

export interface CurrentOdds {
  yes: number
  no: number
}

export interface Outcome {
  id: string
  label: string
  odds: number
}

// Base market properties shared by all market types
interface BaseMarket {
  id: string
  title: string
  imageUrl: string
  categoryTags: string[]
  metaTags: string[]
  volume: number
  liquidity: number
  traderCount: number
  closingDate: string
  createdDate: string
  activeSince: string
  creatorFeePercent: number
  likeCount: number
  isLiked: boolean
}

// Yes/No market type
export interface YesNoMarket extends BaseMarket {
  type: 'yesno'
  currentOdds: CurrentOdds
}

// Categorical market type
export interface CategoricalMarket extends BaseMarket {
  type: 'categorical'
  outcomes: Outcome[]
}

// Numeric market type (NUT-CTF-numeric: HI/LO token pair with proportional payout)
export interface NumericMarket extends BaseMarket {
  type: 'numeric'
  loBound: number    // Lower bound of the outcome range
  hiBound: number    // Upper bound of the outcome range
  precision: number  // Decimal places for display
  unit: string       // Display unit (e.g. "USD", "BTC")
  currentPrice: number // Implied price derived from HI token order book
}

// Union type for all market types
export type Market = YesNoMarket | CategoricalMarket | NumericMarket

// =============================================================================
// Filter Types
// =============================================================================

export type MarketType = 'yesno' | 'categorical' | 'numeric'

export interface VolumeRange {
  min?: number
  max?: number
}

export interface FilterState {
  searchQuery: string
  selectedTag: string | null // Single selected tag (meta or category)
  marketTypes: MarketType[]
  volumeRange: VolumeRange
  closingInDays?: number
}

// =============================================================================
// Trade Mode Types
// =============================================================================

export interface TradeState {
  marketId: string
  outcomeId?: string // For categorical markets
  side: 'yes' | 'no'
  amount: number
  predictedOdds: number
}

// =============================================================================
// Background Data Loading (re-exported from wallet-setup)
// =============================================================================

export type { BackgroundDataLoad } from '../wallet-setup/types'

// =============================================================================
// Component Props
// =============================================================================

export interface MarketDiscoveryProps {
  /** List of meta tags (Trending, Popular, New) */
  metaTags: MetaTag[]

  /** List of category tags for filtering */
  categoryTags: CategoryTag[]

  /** List of markets to display */
  markets: Market[]

  /** Currently selected tag ID (single-select) */
  selectedTag: string | null

  /** Search query */
  searchQuery?: string

  /** Called when user searches for markets */
  onSearch?: (query: string) => void

  /** Called when user selects a tag (single-select - only one active at a time) */
  onTagSelect?: (tagId: string) => void

  /** Called when user changes market type filter */
  onMarketTypeChange?: (types: MarketType[]) => void

  /** Called when user changes volume range filter */
  onVolumeRangeChange?: (range: VolumeRange) => void

  /** Called when user changes closing date filter */
  onClosingDateChange?: (days?: number) => void

  /** Called when user clicks Buy Yes on a yes/no market (triggers Bought event) */
  onBuyYes?: (marketId: string, amount: number) => void

  /** Called when user clicks Buy No on a yes/no market (triggers Bought event) */
  onBuyNo?: (marketId: string, amount: number) => void

  /** Called when user buys Yes on a specific outcome in a categorical market */
  onBuyOutcomeYes?: (marketId: string, outcomeId: string, amount: number) => void

  /** Called when user buys No on a specific outcome in a categorical market */
  onBuyOutcomeNo?: (marketId: string, outcomeId: string, amount: number) => void

  /** Called when user navigates to market detail page */
  onViewMarket?: (marketId: string) => void

  /** Called when user scrolls to bottom and more markets should be loaded */
  onLoadMore?: () => void

  /** Background data loading state (shown as footer progress bar if still loading after wallet setup) */
  backgroundDataLoad?: import('../wallet-setup/types').BackgroundDataLoad

  /** ISO timestamp of last successful condition sync */
  lastUpdatedAt?: string

  /** Triggers re-fetch of conditions from mint */
  onRefreshConditions?: () => void

  /** True while a refresh is in progress (spins the refresh icon) */
  isRefreshing?: boolean
}
